
import db
import manager

myDB = db.db

class CRUD:
    id = db.next_id()
    data = {}
    fields = []
    def __init__(self):
        pass
        
    def setup(self):
        for field in self.fields:
            self.data[field.name] = field.value
        pass

    def dump(self):
        data = self.data
        data["id"] = self.id
        return data

    def get(self):
        return myDB.get(self)

    def post(self, data):
        self.data = data
        return myDB.add(self)

    def put(self, data, id):
        self.id = id
        self.data = data
        return myDB.update(self)
        
    def delete(self, id):
        self.id = id
        return myDB.delete(self)

    
def register(creator):
    manager.register(creator)
