
import db
import ctx

registered_resources = {}

def register(creator):
    global registered_resources

    registered_resources[creator().location] = creator
    

def invoke(location, method, data = None, id = None):
    global registered_resources

    location = "/" + location

    if location not in registered_resources:
        return ctx.error("unknown resource", 1, 404)

    obj = registered_resources[location]()
    obj.setup()
    if method == "GET":
        return obj.get()
    elif method == "POST":
        return obj.post(data)
    elif method == "PUT":
        return obj.put(data, id)
    elif method == "DELETE":
        return obj.delete(id)



    