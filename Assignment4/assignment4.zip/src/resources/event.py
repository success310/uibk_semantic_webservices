import crud
from field import Field

class Event(crud.CRUD):
    data = {}
    location = "/events"

    
crud.register(lambda: Event())