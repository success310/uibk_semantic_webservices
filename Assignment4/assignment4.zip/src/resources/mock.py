import db
import random
import feedparser
from datetime import datetime
import pandas as pd
from random import randrange
from datetime import timedelta

myDB = db.db

url = 'cities.csv'
df = pd.read_csv(url, parse_dates=True, delimiter=",", decimal=",")

myDB.data["/locations"] = {}
for index, row in df.iterrows():
    myDB.data["/locations"][db.next_id()] = { 
            "name": row["city"],  
            "lat": row["lat"],
            "lng": row["lng"],
            "pop": row["pop"],
            "country": row["country"],
            "province": row["province"]
        }

def random_date(start, end):
    delta = end - start
    int_delta = (delta.days * 24 * 60 * 60) + delta.seconds
    random_second = randrange(int_delta)
    return start + timedelta(seconds=random_second)

# Generate events with random locations and a random date
rss_event_feeds = [
    "http://www.brixn.at/feed/",
    #"https://www.events-magazin.de/feed/"
    ]

d1 = datetime.strptime('1/1/2018 1:30 PM', '%m/%d/%Y %I:%M %p')
d2 = datetime.strptime('1/1/2019 4:50 AM', '%m/%d/%Y %I:%M %p')


myDB.data["/events"] = {}
myDB.data["/authors"] = {}
location_ids = list(myDB.data["/locations"].keys())

for url in rss_event_feeds:
    feed = feedparser.parse(url)
    for entry in feed[ "items" ]:   

        authors = [author["name"] for author in entry["authors"]]
        authors_ids = []
        for author in authors:
            author_id = db.next_id()
            authors_ids.append(author_id)
            myDB.data["/authors"][author_id] = { "name": author }

        categories = [t.term for t in entry.get('tags', [])]
        myDB.data["/events"][db.next_id()] = { 
            "title": entry["title"], 
            "description": entry["description"], 
            "categories": categories, 
            "authors": authors_ids, 
            "location":  random.choice(location_ids),
            "date": random_date(d1, d2),
            "link": entry["link"]
        }