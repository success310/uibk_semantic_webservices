import crud

class Location(crud.CRUD):
    data = {}
    location = "/locations"
    
    def __init__(self):
        pass

    
crud.register(lambda: Location())